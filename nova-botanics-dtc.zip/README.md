# Nova Botanics DTC

> High-Volume DTC Subscription Platform

Recurring commerce platform driving +28% retention through 1-click self-serve formula swapping, cadence switcher (30/60/90 days), predictive delivery calendar, and Stripe smart dunning.

Architected by **Niall.M**  
Contact: [niall@nialluk.com](mailto:niall@nialluk.com) | Telegram: [@nialluk](https://t.me/nialluk)

---

## ⚡ Key Highlights

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + Glassmorphism Dark Mode
- **Zero Asset Dependencies**: All product mockups, dashboards, and metrics are 100% CSS & inline SVG
- **Vercel Zero-Config**: Ready for instant production deployment with `npm run build`

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Run local development server
npm run dev

# 3. Build for production
npm run build
npm run start
```

---

## 🌐 Deploy to Vercel

1. Create a new repository on GitHub and push this code:
   ```bash
   git init
   git add .
   git commit -m "feat: initial commit for nova-botanics-dtc"
   git branch -M main
   git remote add origin <your-repo-url>
   git push -u origin main
   ```
2. Import the repository in [Vercel](https://vercel.com/new).
3. Framework Preset: **Next.js** (detected automatically).
4. Click **Deploy**.
