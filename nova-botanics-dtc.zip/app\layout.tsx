import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nova Botanics DTC | High-Volume DTC Subscription Platform",
  description: "Recurring commerce platform driving +28% retention through 1-click self-serve formula swapping, cadence switcher (30/60/90 days), predictive delivery calendar, and Stripe smart dunning.",
  authors: [{ name: "Niall.M" }],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-[#07090e] text-slate-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
