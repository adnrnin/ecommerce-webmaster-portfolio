import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Apex Gear Marketplace | Multi-Vendor B2B & B2C Marketplace",
  description: "High-scale marketplace engine featuring real-time Stripe Connect automated split-settlement ledger, tiered wholesale volume pricing, and distributed Redis inventory mutexes.",
  authors: [{ name: "Niall.M" }],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-[#07090e] text-slate-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
