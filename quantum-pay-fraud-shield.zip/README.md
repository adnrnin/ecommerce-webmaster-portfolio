# Quantum Pay & Fraud Shield

> Custom Global Checkout & Edge Fraud Defense

High-throughput global checkout routing engine with multi-currency FX settlement, real-time Cloudflare Worker edge risk scoring, and dynamic 3D Secure 2.0 fallback.

Architected by **Niall.M**  
Contact: [niall@nialluk.com](mailto:niall@nialluk.com) | Telegram: [@nialluk](https://t.me/nialluk) | WhatsApp: [+44 7446317825](https://wa.me/447446317825)

---

## ⚡ Key Highlights

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + Glassmorphism Dark Mode
- **Zero Asset Dependencies**: All product mockups, dashboards, and metrics are 100% CSS & inline SVG
- **Vercel Zero-Config**: Ready for instant production deployment with `npm run build`

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Run local development server
npm run dev

# 3. Build for production
npm run build
npm run start
```

---

## 🌐 Deploy to Vercel

1. Push to GitHub:
   ```bash
   git init
   git add .
   git commit -m "feat: initial commit for quantum-pay-fraud-shield"
   git branch -M main
   git remote add origin https://github.com/niallmuk/quantum-pay-fraud-shield.git
   git push -u origin main
   ```
2. Import the repository in [Vercel](https://vercel.com/new).
3. Framework Preset: **Next.js** (detected automatically).
4. Click **Deploy**.
