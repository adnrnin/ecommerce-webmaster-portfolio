import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Quantum Pay & Fraud Shield | Custom Global Checkout & Edge Fraud Defense",
  description: "High-throughput global checkout routing engine with multi-currency FX settlement, real-time Cloudflare Worker edge risk scoring, and dynamic 3D Secure 2.0 fallback.",
  authors: [{ name: "Niall.M" }],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-[#07090e] text-slate-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
